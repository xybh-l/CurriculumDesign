#pragma once
#include"others.h"
#include"Teacher.h"
#include<iostream>
#include<string>
#include<fstream>
using namespace std;

extern int StudentNumber;
class Student
{
private:
	string id;
	string name;
	int classid;
	double chinese;
	double math;
	double english;
	double sum;//�ܳɼ�
	double aver;//ƽ���ɼ�
public:
	//void Show();
	void add(Teacher t);
	friend ifstream & operator >>(ifstream & in, Student & S) {
		in >> S.id >> S.name >> S.classid >> S.chinese >> S.math >> S.english >> S.sum >> S.aver;
		return in;
	}
	friend void QueryStudentInfo(int id);
	friend void DeleteStudentInfo(int id);
	friend void ModifyStudentInfo(int id);
	friend void StudentSystem();
	friend void WriteStudentInfo();
};