#pragma once

#include"Global.h"
#include<iostream>
#include<conio.h>
#include<Windows.h>
#include<fstream>
#ifndef OTHERS_H_
#define OTHERS_H_

using namespace std;
void gotoxy(int, int); 
void draw();
void WriteStudentInfo();
void WriteImport();

#endif // !OTHERS_H_

