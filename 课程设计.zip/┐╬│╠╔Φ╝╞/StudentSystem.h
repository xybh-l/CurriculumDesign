#pragma once

#include"others.h"
#include<iostream>
using namespace std;
void StudentSystem();