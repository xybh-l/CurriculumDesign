#pragma once

#include "Student.h"
#include "Teacher.h"

//static Student S[2];
//static Teacher T[100];


//static int StudentNumber = 0;
//static int TeacherNumber = 0;
//extern int TeacherNumber;
//extern int StudentNumber;