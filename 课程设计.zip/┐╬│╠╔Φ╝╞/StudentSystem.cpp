#include "StudentSystem.h"

extern Student S[100];
void StudentSystem()
{
	int x = 20;
	int y = 20;
	string tid;
	system("cls");
	gotoxy(x, y);
	cout << "***************************************";
	for (int i = 1; i < 10; i++)
	{
		gotoxy(x, y+i);
		cout << "*                                     *";
	}
	cout << "***************************************";
	cout << "���������ѧ��";
	cin >> tid;
	for (int i = 0; i < StudentNumber; i++)
	{
		if (S[i].id == tid)
		{

		}
	}
}
